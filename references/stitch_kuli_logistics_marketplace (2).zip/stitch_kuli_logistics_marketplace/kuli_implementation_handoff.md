# KULI App Implementation Handoff & Architecture Plan

## 1. System Overview
**Framework**: React Native (Expo SDK)
**Styling**: NativeWind (Tailwind CSS for React Native) or StyleSheet
**Navigation**: React Navigation (Stack & Tabs)

---

## 2. Global Design Tokens (Theme)
```json
{
  "colors": {
    "primary": "#000000",
    "secondary": "#FFFFFF",
    "background": "#F5F5F5",
    "surface": "#FFFFFF",
    "success": "#27A644",
    "warning": "#F9A825",
    "error": "#DC3545",
    "text": {
      "primary": "#000000",
      "secondary": "#666666",
      "onPrimary": "#FFFFFF"
    },
    "border": "#E5E5E5"
  },
  "spacing": {
    "xs": 4,
    "sm": 8,
    "md": 16,
    "lg": 24,
    "xl": 32
  },
  "radius": {
    "sm": 8,
    "md": 12,
    "lg": 16,
    "full": 9999
  }
}
```

---

## 3. Reusable Component Structure
`src/components/`
- `ui/`: Atomic elements (Button, Input, Badge, Typography)
- `cards/`: Domain-specific cards (VehicleCard, DriverCard, TripCard)
- `layout/`: Containers (ScreenWrapper, Section, BottomSheet)
- `navigation/`: Custom TabBars and Headers

---

## 4. Screen Specifications (Sample Phase 1)

### Screen: Client Home
- **Route**: `client/home`
- **Role**: Client
- **Main Components**: `HeroBanner`, `ServiceGrid`, `RecentTripsList`, `FloatingActionButton`
- **Backend Data**: `userProfile`, `activeServices`, `recentTrips`
- **States**:
  - **Empty**: "No active moves yet" illustration with "Book Now" CTA.
  - **Loading**: Skeleton loaders for the ServiceGrid and RecentTrips.
  - **Error**: Retry toast for failed trip history fetch.
- **Actions**: `onPressService`, `onPressRequestTruck`, `onViewHistory`
- **Navigation**: Home Tab -> Service Detail (Stack)

### Screen: Fleet Dashboard
- **Route**: `owner/fleet`
- **Role**: Owner
- **Main Components**: `StatSummary`, `UtilizationBar`, `FilterTabs`, `VehicleCardList`
- **Backend Data**: `fleetStats`, `vehicleList (filtered)`
- **States**:
  - **Empty**: "No vehicles registered" placeholder.
  - **Loading**: Pulse animation on stats and cards.
- **Actions**: `onFilterChange`, `onPressVehicleDetails`, `onAssignTask`
- **Navigation**: Fleet Tab -> Vehicle Profile (Stack)

---

## 5. Navigation Structure

### Client Tabs
1. **Explore**: Home screen & service discovery.
2. **Orders**: Active and past requests.
3. **Wallet**: Payments & credits.
4. **Profile**: Settings & help.

### Owner Tabs
1. **Fleet**: Dashboard & vehicle management.
2. **Drivers**: Driver pool & assignments.
3. **Earnings**: Financial insights.
4. **Account**: Profile & settings.

---

## 6. Implementation Roadmap

1. **Step 1: Foundation**: Set up `theme.ts` and base UI components (Button, Typography, Card).
2. **Step 2: Core Navigation**: Implement the Tab and Stack structures for both roles.
3. **Step 3: Client Priority**: Rebuild the **Client Home (SCREEN_47)** and **Request Flow** first—these are the primary revenue drivers.
4. **Step 4: Owner Essentials**: Build the **Fleet Dashboard (SCREEN_5)** and **Earnings (SCREEN_41)**.
5. **Step 5: Operational Flows**: Driver Assignment and Verification.
6. **Step 6: Support & Messaging**: Finalize the Help Center and Chat.