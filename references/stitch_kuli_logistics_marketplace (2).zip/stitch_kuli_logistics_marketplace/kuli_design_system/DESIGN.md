---
name: KULI Design System
colors:
  surface: '#f9f9f6'
  surface-dim: '#dadad7'
  surface-bright: '#f9f9f6'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f4f1'
  surface-container: '#eeeeeb'
  surface-container-high: '#e8e8e5'
  surface-container-highest: '#e2e3e0'
  on-surface: '#1a1c1b'
  on-surface-variant: '#4c4546'
  inverse-surface: '#2f312f'
  inverse-on-surface: '#f1f1ee'
  outline: '#7e7576'
  outline-variant: '#cfc4c5'
  surface-tint: '#5e5e5e'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1b1b1b'
  on-primary-container: '#848484'
  inverse-primary: '#c6c6c6'
  secondary: '#006e2c'
  on-secondary: '#ffffff'
  secondary-container: '#93f9a1'
  on-secondary-container: '#00742f'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#2e1600'
  on-tertiary-container: '#bf7119'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2e2e2'
  primary-fixed-dim: '#c6c6c6'
  on-primary-fixed: '#1b1b1b'
  on-primary-fixed-variant: '#474747'
  secondary-fixed: '#93f9a1'
  secondary-fixed-dim: '#78dc87'
  on-secondary-fixed: '#002108'
  on-secondary-fixed-variant: '#00531f'
  tertiary-fixed: '#ffdcc0'
  tertiary-fixed-dim: '#ffb877'
  on-tertiary-fixed: '#2e1600'
  on-tertiary-fixed-variant: '#6c3b00'
  background: '#f9f9f6'
  on-background: '#1a1c1b'
  surface-variant: '#e2e3e0'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  title-sm:
    fontFamily: Inter
    fontSize: 17px
    fontWeight: '600'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 8px
  sm: 12px
  md: 16px
  lg: 24px
  xl: 32px
  edge_margin: 20px
  gutter: 16px
---

## Brand & Style

The design system is engineered for a high-fidelity, peer-to-peer logistics ecosystem. It balances the grit of heavy-duty moving with the precision of modern technology. The brand personality is **authoritative, efficient, and transparent**, aiming to build immediate trust between independent truck owners and urban customers.

The visual style follows a **Corporate / Modern** aesthetic with **Tactile** influences. It utilizes a map-centric layout philosophy where UI elements appear as physical, floating layers above the terrain. High-contrast typography and a restricted color palette ensure clarity in high-pressure logistics environments, while generous whitespace and soft-edged containers provide a premium, consumer-grade experience similar to leading global ride-hailing platforms.

## Colors

The palette is anchored by a sophisticated **Primary Black** and **Pure White** foundation to evoke a sense of professional logistics and high-end service. 

- **Foundation:** Use `Off-white Background` (#F6F6F3) for the main application canvas to reduce eye strain. `Pure White` is reserved specifically for elevated cards and sheets.
- **Action & Status:** `Success Green` is the primary indicator for active movement and completed transactions. `Warning Amber` is used for "Action Required" states such as pending payments or unread logistics alerts.
- **Surface Hierarchy:** For dark-mode components or high-emphasis headers, use `Near Black` (#111111). Borders should remain subtle using #E6E6E6 to maintain a clean, airy feel without compartmentalizing the UI too aggressively.

## Typography

This design system utilizes **Inter** for its neutral, highly legible characteristics. The type scale is optimized for quick scanning—essential for users who may be interacting with the app while on the move or in busy loading zones.

- **Headlines:** Use tight letter spacing (-0.02em) on larger displays to create a more "editorial" and premium feel. 
- **Readability:** Body text is set at 15px with a generous 22px line height to ensure clarity against map backgrounds and within dense logistics data tables.
- **Hierarchy:** Captions and labels use Medium weight (500) to ensure visibility even at the smallest scale of 12px.

## Layout & Spacing

The layout is **Map-First** and fluid. On mobile devices, the base map occupies the full viewport, with UI elements appearing as floating modules. 

- **Grid:** A 4-column grid for mobile and 12-column for desktop. 
- **Safe Areas:** Maintain a 20px edge margin for all floating elements (buttons, sheets) to ensure they do not feel cramped against the screen edge.
- **Rhythm:** All spacing follows a 4px baseline. Use 16px (md) for internal card padding and 24px (lg) for vertical separation between distinct sections.
- **Floating Sheets:** Bottom sheets should never touch the side edges of the screen on larger devices (tablets), maintaining a "card-in-space" feel.

## Elevation & Depth

Depth is used to represent the "stack" of the logistics process.

- **Level 0 (Map/Canvas):** The base layer.
- **Level 1 (Cards):** Low-offset shadows (4px Y-axis, 12px Blur, 4% Black) to distinguish white cards from the #F6F6F3 background.
- **Level 2 (Floating Sheets & Navigation):** Higher elevation with extra-diffused shadows (12px Y-axis, 24px Blur, 8% Black). These surfaces should feel physically "above" the map.
- **Interactive States:** When a card is pressed, it should subtly shrink (scale 0.98) and its shadow should decrease, simulating a physical push.

## Shapes

The shape language is purposefully **Rounded** to contrast with the industrial nature of trucks and moving. 

- **Primary Containers:** Cards and Bottom Sheets use a generous 20px radius to feel approachable.
- **Action Elements:** Buttons use a tighter 12px radius, providing enough roundness to feel modern while maintaining enough "squareness" to look stable and professional.
- **Status Badges:** Always use pill-shapes (fully rounded) to differentiate them from interactive buttons or cards.

## Components

- **Buttons:** Large touch targets (min 52px height). Primary buttons are solid Primary Black with White text. Secondary buttons use a White fill with a 1px #E6E6E6 border.
- **Floating Bottom Sheets:** These are the primary navigation pattern. They should include a "grabber" handle (40x4px, #E6E6E6) at the top and support variable heights (Peek, Standard, Expanded).
- **Status Badges:** Small pill-shaped containers. `Success` uses a light green tint background with dark green text. `Warning` uses a light amber tint.
- **Input Fields:** Clean, 1px bordered boxes with 12px radius. Labels sit above the field in 12px Medium type. Focus state is indicated by a 1.5px Primary Black border.
- **Vehicle Cards:** High-contrast cards featuring a silhouette of the truck type, price (Headline-md), and estimated arrival time.
- **Map Markers:** Custom black pins for pickups and green pins for drop-offs, utilizing the same shadow logic as the floating cards.