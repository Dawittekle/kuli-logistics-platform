---
name: KULI Premium
colors:
  surface: '#fbf9f8'
  surface-dim: '#dbdad9'
  surface-bright: '#fbf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3f3'
  surface-container: '#efeded'
  surface-container-high: '#e9e8e7'
  surface-container-highest: '#e4e2e2'
  on-surface: '#1b1c1c'
  on-surface-variant: '#4c4546'
  inverse-surface: '#303031'
  inverse-on-surface: '#f2f0f0'
  outline: '#7e7576'
  outline-variant: '#cfc4c5'
  surface-tint: '#5e5e5e'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1b1b1b'
  on-primary-container: '#848484'
  inverse-primary: '#c6c6c6'
  secondary: '#5d5f5f'
  on-secondary: '#ffffff'
  secondary-container: '#dcdddd'
  on-secondary-container: '#5f6161'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#1b1b1b'
  on-tertiary-container: '#848484'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2e2e2'
  primary-fixed-dim: '#c6c6c6'
  on-primary-fixed: '#1b1b1b'
  on-primary-fixed-variant: '#474747'
  secondary-fixed: '#e2e2e2'
  secondary-fixed-dim: '#c6c6c7'
  on-secondary-fixed: '#1a1c1c'
  on-secondary-fixed-variant: '#454747'
  tertiary-fixed: '#e2e2e2'
  tertiary-fixed-dim: '#c6c6c6'
  on-tertiary-fixed: '#1b1b1b'
  on-tertiary-fixed-variant: '#474747'
  background: '#fbf9f8'
  on-background: '#1b1c1c'
  surface-variant: '#e4e2e2'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  gutter: 16px
  margin-mobile: 16px
  margin-desktop: 32px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 24px
---

## Brand & Style
The design system is engineered for a professional, commercial-grade experience that prioritizes clarity, efficiency, and trust. Drawing inspiration from modern high-end logistics and service platforms, the aesthetic is rooted in a refined **Corporate Modern** style. 

The brand personality is authoritative yet accessible, using a stark monochrome palette to signify reliability. The user interface minimizes visual noise, focusing on large tap targets and a high-contrast information hierarchy to ensure usability in fast-paced, real-world environments. The emotional response should be one of total control, safety, and seamless execution.

## Colors
The palette is intentionally restrained to maximize the impact of brand actions and status indicators. 

- **Primary Black (#000000):** Used for primary buttons, core branding, and high-level headings. It represents the "Uber-like" premium authority.
- **Surface Neutrals (#FFFFFF, #F3F3F3):** Pure white is the base for all primary content areas. The light gray (#F3F3F3) is used for background fills, input fields, and secondary containers to create soft depth without heavy shadows.
- **Semantic Logic:** Status colors (Green, Amber, Red) are used only for functional feedback. They should be paired with low-opacity backgrounds of the same hue for "Chip" or "Badge" components to ensure high legibility while maintaining a sophisticated look.

## Typography
This design system utilizes **Inter** exclusively to achieve a systematic, utilitarian aesthetic. 

The hierarchy is built on heavy weight contrast. Headlines must be bold and tightly tracked to feel impactful. Body text remains generous in line-height to ensure readability during transit or outdoors. 

For mobile views, headline sizes are scaled down to prevent awkward line breaks while maintaining their bold weight. Labels use a slightly increased letter-spacing and medium-to-bold weights to ensure they are distinct from body paragraphs.

## Layout & Spacing
The layout follows a strict 4px baseline grid to ensure mathematical harmony across all components.

- **Mobile First:** A fluid 4-column grid is used for mobile with 16px side margins. 
- **Desktop:** A 12-column fixed-width grid (max-width 1200px) is preferred for administrative dashboards.
- **Rhythm:** Use `stack-md` (16px) for standard vertical spacing between related elements and `stack-lg` (24px) to separate distinct sections. Large tap targets must be at least 48px to 56px in height to accommodate mobile interaction.

## Elevation & Depth
This design system uses a **Tonal Layering** approach supplemented by subtle shadows for high-priority floating elements.

- **Level 0 (Base):** #FFFFFF for the primary background.
- **Level 1 (Sectioning):** #F3F3F3 for input fields, secondary cards, or background grouping.
- **Level 2 (Floating):** Bottom sheets, tooltips, and floating action buttons use a soft, diffused shadow: `0px 8px 24px rgba(0, 0, 0, 0.08)`.
- **Level 3 (Overlay):** Modals use a high-contrast scrim (40% opacity black) to focus the user’s attention.

Avoid using shadows on static cards; use 1px borders in #F3F3F3 or subtle background shifts instead to keep the UI feeling "flat" and modern.

## Shapes
The shape language is defined by **Soft Roundedness**, striking a balance between approachable and professional.

- **Standard Elements:** Buttons and input fields use a consistent 12px radius.
- **Large Containers:** Cards and Bottom Sheets use a 16px radius for a more pronounced "premium" feel.
- **Interactive States:** High-frequency components like checkboxes use a smaller 4px radius to maintain precision.

## Components
- **Buttons:** Primary buttons are solid #000000 with white text, 56px height. Secondary buttons use #F3F3F3 with black text. No borders.
- **Input Fields:** 12px rounded corners with #F3F3F3 fill. On focus, the field remains light gray but gains a 2px solid black internal stroke.
- **Cards:** White background with 16px rounding and a subtle 1px #F3F3F3 border. Padding is consistently 20px.
- **Chips/Badges:** Small, 12px height text inside 32px rounded capsules. Use low-saturation background tints (e.g., Success Green at 10% opacity) with high-saturation text.
- **Bottom Sheets:** Essential for the mobile experience. 16px top-rounded corners, utilizing the Level 2 shadow. Drag handle should be a subtle 4px thick #E0E0E0 bar.
- **Lists:** Clean rows with 16px vertical padding, separated by 1px #F3F3F3 dividers that do not extend to the edge of the screen (inset dividers).