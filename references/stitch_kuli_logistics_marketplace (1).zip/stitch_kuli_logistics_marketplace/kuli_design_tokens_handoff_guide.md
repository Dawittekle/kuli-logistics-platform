# KULI Premium Design System (React Native)

## 1. Colors
- **Brand Primary**: `#000000` (Black)
- **Background**: `#FFFFFF` (White)
- **Surface**: `#F5F5F5` (Light Gray)
- **Success**: `#27A644` (Green) - Use for: Online, Approved, Completed, Active.
- **Pending/Warning**: `#F9A825` (Amber) - Use for: Unread, Payment Needed, Pending.
- **Error/Destructive**: `#DC3545` (Red) - Use for: Cancelled, Rejected, Disputes.

## 2. Typography
- **Font Family**: Inter (Primary)
- **Display**: 32px/Bold (Hero greetings)
- **Headline**: 24px/SemiBold (Section titles)
- **Body**: 16px/Regular (Standard text)
- **Label**: 14px/Medium (Secondary info, buttons)

## 3. Spacing & Radius
- **Padding**: 16px (Base margin), 24px (Large padding)
- **Gutter**: 12px
- **Border Radius**: 16px (Main cards, Bottom sheets), 8px (Inner elements)

## 4. Components & Variants
- **PrimaryButton**: Full-width, Black bg, White text, 16px radius.
- **StatusBadge**: Pill-shaped, subtle bg with status-colored text.
- **BottomSheet**: Screen-width, rounded top, soft shadow elevation.
- **TruckCard**: White bg, 1px border; Active state: Black bg, White text.
- **AppHeader**: Transparent or Surface bg, high contrast icons.

## 5. Screen Implementation Notes
- **Maps**: Use `react-native-maps`. Style with silver/minimalist theme.
- **Animations**: Use `react-native-reanimated` for Bottom Sheet transitions and status pulses.
- **Haptics**: Add `expo-haptics` for button presses and status updates.
