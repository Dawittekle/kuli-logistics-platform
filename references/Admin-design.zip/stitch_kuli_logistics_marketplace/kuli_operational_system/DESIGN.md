---
name: KULI Operational System
colors:
  surface: '#fcf9f8'
  surface-dim: '#dcd9d9'
  surface-bright: '#fcf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f2'
  surface-container: '#f0edec'
  surface-container-high: '#ebe7e7'
  surface-container-highest: '#e5e2e1'
  on-surface: '#1c1b1b'
  on-surface-variant: '#42474b'
  inverse-surface: '#313030'
  inverse-on-surface: '#f3f0ef'
  outline: '#73787b'
  outline-variant: '#c2c7cb'
  surface-tint: '#4b616e'
  primary: '#000204'
  on-primary: '#ffffff'
  primary-container: '#071f2a'
  on-primary-container: '#718895'
  inverse-primary: '#b3cad9'
  secondary: '#356478'
  on-secondary: '#ffffff'
  secondary-container: '#b7e7fe'
  on-secondary-container: '#39687d'
  tertiary: '#050100'
  on-tertiary: '#ffffff'
  tertiary-container: '#2c1805'
  on-tertiary-container: '#9f7e63'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#cee6f5'
  primary-fixed-dim: '#b3cad9'
  on-primary-fixed: '#061e29'
  on-primary-fixed-variant: '#344a56'
  secondary-fixed: '#bde9ff'
  secondary-fixed-dim: '#9ecde4'
  on-secondary-fixed: '#001f2a'
  on-secondary-fixed-variant: '#194c60'
  tertiary-fixed: '#ffdcc1'
  tertiary-fixed-dim: '#e5bfa1'
  on-tertiary-fixed: '#2b1704'
  on-tertiary-fixed-variant: '#5b412a'
  background: '#fcf9f8'
  on-background: '#1c1b1b'
  surface-variant: '#e5e2e1'
typography:
  metric-lg:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  sidebar-width: 260px
  gutter: 24px
  container-max: 1440px
---

## Brand & Style

The design system is engineered for high-stakes operational environments, specifically tailored for logistics and enterprise administration. The brand personality is **authoritative yet understated**, prioritizing functional clarity over decorative flair. It evokes a sense of **operational calm**—the feeling of a complex machine running perfectly in the background.

The visual style is a hybrid of **Minimalism** and **Modern Corporate**, drawing inspiration from industry leaders like Stripe and Linear. It utilizes a sophisticated "warm-industrial" palette that replaces sterile grays with a grounded off-white background and deep navy accents. This approach reduces eye strain for long-duration usage while maintaining a premium, trustworthy aesthetic. 

Key attributes:
- **Precision:** Every pixel serves a purpose in data visualization.
- **Reliability:** Heavy use of structured borders and clear hierarchies.
- **Sophistication:** Subtle use of depth and high-quality typography to elevate the administrative experience.

## Colors

This design system utilizes a high-contrast palette balanced by soft, warm neutral tones. The **Primary Dark (#071F2A)** serves as the anchor, used for the sidebar and primary actions to command attention without the harshness of pure black.

The **Background (#F7F5EF)** provides a unique warmth that differentiates the product from standard "SaaS Blue" interfaces. Surfaces are layered using **Surface (#FFFFFF)** for cards and active elements, and **Soft Surface (#FBFAF7)** for secondary containers or recessed areas.

**Semantic Colors** (Success, Warning, Error, Info) are slightly desaturated to maintain the professional tone while ensuring critical status information is immediately recognizable. All borders should utilize the **#E4DFD4** token to create a soft, etched appearance rather than a hard line.

## Typography

The design system relies exclusively on **Inter** to ensure maximum legibility across dense data environments. The scale is optimized for dashboards, featuring a specialized `metric-lg` style for high-level KPIs and compact `body-sm` and `label` styles for table row data and metadata.

**Hierarchy Rules:**
- **Metrics:** Use `metric-lg` with Semi-Bold weights to make numbers pop.
- **Tables:** Data should predominantly use `body-sm` or `body-md` for high information density.
- **Captions:** Use `label-sm` with uppercase transformation for column headers and section small-titles to create clear separation.
- **Legibility:** Maintain a tight letter-spacing on larger headlines to mirror modern software aesthetics (Linear-style).

## Layout & Spacing

The design system uses a **fixed-fluid hybrid grid**. A permanent **260px sidebar** anchors the left side, while the main content area resides in a fluid container with a maximum width of **1440px** to prevent line-lengths from becoming unreadable on ultra-wide monitors.

**Grid System:**
- Use a **12-column fluid grid** for the main content area.
- Gutters are fixed at **24px** (lg) to provide enough breathing room between dense data cards.
- Layout margins should scale: **16px** on mobile, **24px** on tablet/desktop.

**Spacing Rhythm:**
Everything is built on a **4px base unit**. Component internal padding typically uses **8px** (sm) or **12px** (between sm and md) for a tight, professional feel, while section vertical spacing uses **32px** (xl) to clearly delineate different modules of the dashboard.

## Elevation & Depth

This design system prioritizes **Tonal Layers** and **Low-Contrast Outlines** over heavy shadows. This creates a flat, "architectural" feel that suits professional software.

- **Level 0 (Background):** The warm off-white `#F7F5EF` serves as the canvas.
- **Level 1 (Cards/Surfaces):** White `#FFFFFF` surfaces with a 1px solid border of `#E4DFD4`. No shadow.
- **Level 2 (Dropdowns/Popovers):** White surfaces with a very subtle, diffused shadow: `0px 4px 12px rgba(7, 31, 42, 0.08)`.
- **Level 3 (Modals):** White surfaces with a more pronounced shadow: `0px 12px 32px rgba(7, 31, 42, 0.12)`.

To create depth without shadows, use the **Soft Surface (#FBFAF7)** for recessed areas like empty states or side-panels within a view.

## Shapes

The shape language is **structured and disciplined**. By using a `Soft (1)` rounding scale, the UI maintains a professional "tool-like" appearance without feeling aggressive or overly playful.

- **Standard Elements:** 4px (0.25rem) for buttons, input fields, and small tags.
- **Containers:** 8px (0.5rem) for main dashboard cards and modals.
- **Selection States:** Use sharp or 2px corners for indicators (like the active state in a sidebar) to emphasize precision.

## Components

### Buttons & Inputs
- **Primary Action:** Deep Navy background (`#071F2A`) with White text. Small 4px radius.
- **Secondary Action:** White background with a 1px border (`#E4DFD4`).
- **Inputs:** Use the Soft Surface (`#FBFAF7`) for the background of inactive inputs to help them blend, switching to White on focus with a 1px Primary Navy border.

### Tables (High Density)
- **Header Row:** Use `label-sm` (uppercase) with a subtle bottom border.
- **Rows:** 48px height for standard, 40px for condensed views. 
- **Zebra Striping:** Not required; use thin 1px horizontal dividers (`#E4DFD4`) instead to maintain a clean look.

### Metric Cards
- Should feature the `metric-lg` value prominently.
- Include a small trend indicator (pill-shaped tag) using semantic Success or Error colors at 10% opacity for the background and 100% for the text.

### Sidebar Navigation
- Background: Primary Dark (`#071F2A`).
- Text: Muted gray-blue (`#98A2B3`) for inactive states, White for active.
- Active State: A subtle 2px vertical "light bar" on the far left or a subtle background tint change.

### Split-Panel Layouts
- Use for "Details" views. The left panel contains the list/table, and the right panel (recessed with Soft Surface `#FBFAF7`) contains the expanded record details. Separate with a vertical 1px border.